function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
    line (320,250,180,120)
    line (70,230,160,150)
      ellipse(220,250,20,90);
      ellipse(165,250,20,90);
        square(152,149,80);
         rect(152,149,80,40);
            circle(190,120,70);
            circle(172,120,2);
            circle(205,120,2);
              point(190,200,10);
                triangle(140, 115, 310, 114, 120, 45);
   text('Me with Simple Shapes!!!', 10, 30);
   text('By: Joshua Scrivner', 200, 350);
}  